import logo from './logo.svg';
import './App.css';
import Products from './components/Products';
import Product from './components/Product';
function App() {
  return (
    <div className="App">
      <Products />
      <hr />
      <Product />
    </div>
  );
}

export default App;
